# RectiControl Pro (Taller)

Sistema para rectificadora con enfoque operativo profesional:

- Login por empleado.
- Estados estandarizados: `Ingresado`, `En proceso`, `Terminado`, `Cancelado`, `Entregado`.
- Numeracion automatica:
  - `Motor-0001`
  - `TapaCliente-0001`
  - `Repuesto-0001`
  - `Presupuesto-0001`
- Prioridad: `Normal`, `Urgente`, `Muy urgente`.
- Asignacion de empleado por trabajo.
- Buscador por cliente, vehiculo o numero.
- Fecha prometida + alerta de atraso.
- Contadores superiores de control.
- Botones rapidos por tarjeta: `Terminar`, `Cancelar`, `Entregar`.
- Notificacion visual + sonido al terminar/cancelar.
- Envio online por WhatsApp de presupuestos/repuestos.
- Pestana dedicada `Presupuestos` con PDF detallado (descargar/compartir).

## Abrir

1. Abrir `index.html`.
2. Iniciar sesion con un usuario.

## Usuarios demo

- Usuario: `admin` | Contrasena: `admin123`
- Usuario: `juan` | Contrasena: `1234`
- Usuario: `maria` | Contrasena: `1234`

Desde la pestana `Clientes` podes crear mas empleados con su login.

## Publicar online (Android y iOS)

Archivo listo para subir: `recticontrol-online.zip`

Pasos rapidos:

1. Entrar a [Netlify Drop](https://app.netlify.com/drop).
2. Arrastrar `recticontrol-online.zip` o descomprimirlo y arrastrar la carpeta.
3. Netlify genera un link publico (ej: `https://recticontrol-parra.netlify.app`).
4. Compartir ese link por WhatsApp a todos los empleados.

Instalar como app en celulares:

- Android (Chrome): menu -> `Agregar a pantalla de inicio`.
- iPhone (Safari): compartir -> `Agregar a inicio`.

Nota importante:

- Si `supabase-config.js` no tiene credenciales, funciona en modo local por dispositivo.
- Si completas Supabase, todos ven los mismos datos en tiempo real.

## Activar sincronizacion en tiempo real (Supabase)

1. Crear proyecto en Supabase.
2. En SQL Editor ejecutar:

```sql
create table if not exists employees (
  id text primary key,
  name text not null,
  username text not null unique,
  password text not null
);

create table if not exists clients (
  id text primary key,
  name text not null,
  phone text not null,
  email text,
  address text
);

create table if not exists jobs (
  id text primary key,
  number text not null,
  type text not null,
  vehicle text not null,
  clientId text not null,
  priority text not null,
  assignedEmployeeId text,
  status text not null,
  inDate text,
  promisedDate text,
  outDate text
);

create table if not exists quotes (
  id text primary key,
  number text not null,
  clientId text not null,
  type text not null,
  description text not null,
  items text,
  labor numeric not null default 0,
  parts numeric not null default 0,
  total numeric not null default 0,
  date text
);

create table if not exists history (
  id text primary key,
  message text not null,
  by text not null,
  at text not null
);

create table if not exists app_settings (
  id int primary key,
  counters jsonb not null
);

insert into app_settings (id, counters)
values (1, '{"motor":0,"tapa":0,"repuesto":0,"presupuesto":0}')
on conflict (id) do nothing;
```

3. En `Database -> Replication` activar cambios para:
   - `employees`
   - `clients`
   - `jobs`
   - `quotes`
   - `history`
   - `app_settings`
4. En [supabase-config.js](C:\Users\forev\Documents\New project\supabase-config.js) completar:
   - `url`
   - `anonKey`
5. Volver a publicar en Netlify.

Cuando este activo vas a ver la etiqueta `Nube` en la cabecera.

Para una puesta en marcha rapida, en `Authentication -> Policies` desactiva RLS de estas tablas o crea politicas de lectura/escritura para el rol `anon`.
