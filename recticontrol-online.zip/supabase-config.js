window.__SUPABASE_CONFIG = {
  // Completar con tus credenciales de Supabase para activar sincronizacion en tiempo real
  // url: "https://TU-PROYECTO.supabase.co",
  // anonKey: "TU_ANON_KEY",
  url: "",
  anonKey: "",
};
